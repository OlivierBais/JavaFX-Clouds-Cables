module com.example.cloudsandcables {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.cloudsandcables to javafx.fxml;
    exports com.example.cloudsandcables;
}