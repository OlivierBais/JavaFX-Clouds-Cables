package com.example.cloudsandcables.objects;

import javafx.geometry.Insets;

public class Constants {
    public static final int FINAL_TILE = 100; // The final tile number is normally 100, but can be changed for testing purposes.
    public static final Insets TOP_LEFT = new Insets(40,0,0,0);
    public static final Insets TOP_RIGHT = new Insets(40,0,0,16);
    public static final Insets BOTTOM_LEFT = new Insets(70,0,0,0);
    public static final Insets BOTTOM_RIGHT = new Insets(70,0,0,16);
}
