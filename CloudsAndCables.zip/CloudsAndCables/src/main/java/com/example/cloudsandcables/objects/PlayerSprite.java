package com.example.cloudsandcables.objects;

import java.util.HashMap;

import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

public class PlayerSprite extends Pane {
    private ImageView sprite;
    private HashMap<String, Image> spriteMap;
    private String[] colorsArray = { "Red", "Green", "Yellow", "Blue", "Black", "White", "Pink", "Brown", "Orange",
            "Purple", "Gray" };

    public PlayerSprite() {
        this.spriteMap = new HashMap<String, Image>();
        populateSpriteMap();
        Image file = new Image(
                "C:\\Users\\BaisOlivier(Calco)\\JavaProject\\CloudsAndCables\\CloudsAndCables\\src\\main\\java\\com\\example\\cloudsandcables\\images\\RedSprite.png");
        this.sprite = new ImageView(file);
        this.sprite.setX(6);
        this.sprite.setY(18);
        this.getChildren().add(this.sprite);
    }

    public PlayerSprite(String color) {
        this.spriteMap = new HashMap<String, Image>();
        populateSpriteMap();
        Image spritePNG = this.getSprite(color);
        this.sprite = new ImageView(spritePNG);
        this.sprite.setX(6);
        this.sprite.setY(18);
        this.getChildren().add(this.sprite);
    }

    /**
     * Populates the hashmap containing colors (strings) and associated sprites.
     */
    public void populateSpriteMap() {
        // Local path is not ideal.
        String path = "C:\\Users\\BaisOlivier(Calco)\\JavaProject\\CloudsAndCables\\CloudsAndCables\\src\\main\\java\\com\\example\\cloudsandcables\\images\\";
        String dotPNG = "Sprite.png"; // End portion of path
        for (String color : colorsArray) { // Loop over all available colors
            this.spriteMap.put(color, new Image(path + color + dotPNG)); // Concatenate strings to extract each color.
        }
    }

    public Image getSprite(String color) {
        return this.spriteMap.get(color);
    }
    /**
     * Align sprites so they do not overlap with the board or each other
     * @param color
     * @param playerNum
     */
    public void setSpriteValues(String color, int playerNum) {
        this.sprite.setImage(this.getSprite(color));
        switch (playerNum) {
            case 1:
                this.sprite.setX(6);
                this.sprite.setY(18);
                break;
            case 2:
                this.sprite.setX(31);
                this.sprite.setY(18);
                break;
            case 3:
                this.sprite.setX(6);
                this.sprite.setY(43);
                break;
            case 4:
                this.sprite.setX(31);
                this.sprite.setY(43);
                break;

            default:
                System.out.println("ERROR: PlayerNum not found by PlayerSprite.setSpriteValues");
                break;
        }
    }
    /**
     * Rotate clockwise by 360 degrees over 1 second
     */
    public void rotate(){
        RotateTransition rotate = new RotateTransition();
        rotate.setNode(this.sprite);
        rotate.setAxis(Rotate.Z_AXIS); // Set the rotation axis back to Z, just in case.
        rotate.setDuration(Duration.millis(1000));
        rotate.setByAngle(360);
        rotate.play();
    }
    /**
     * Expand and contract sprite
     */
    public void rescale(){
        ScaleTransition upscale = new ScaleTransition();
        upscale.setNode(this.sprite);
        upscale.setDuration(Duration.millis(500)); // The whole thing takes a second
        upscale.setByX(1); // This will double the sprite's size
        upscale.setByY(1);
        upscale.setAutoReverse(true);
        upscale.setCycleCount(2); // Ensures the sprite grows and then shrinks again
        upscale.play();
    }
    /**
     * do a lil dance
     */
    public void cloudDance(){
        RotateTransition rotate = new RotateTransition();
        rotate.setAxis(Rotate.Z_AXIS); // Set the rotation axis back to Z, just in case.
        rotate.setNode(this.sprite);
        rotate.setDuration(Duration.millis(250)); // 240RPM
        rotate.setByAngle(360);
        rotate.setInterpolator(Interpolator.LINEAR); // Ensure smooth rotation
        rotate.setCycleCount(4); // Rotate 4 times
        rotate.play();
    }
    /**
     * do a lil dance
     */
    public void cableDance(){
        RotateTransition tumble = new RotateTransition();
        tumble.setNode(this.sprite);
        tumble.setDuration(Duration.millis(250)); // 4 tumbles per second
        tumble.setAxis(Rotate.X_AXIS); // Set rotation axis to X, so the sprite tumbles end-over-end
        tumble.setByAngle(360);
        tumble.setInterpolator(Interpolator.LINEAR); // Ensures smooth rotation
        tumble.setCycleCount(4); // Rotate 4 times
        tumble.play();
        tumble.setAxis(Rotate.Z_AXIS); // Set the rotation axis back to Z, just in case.
    }
    /**
     * rotate and grow the sprite, to draw attention to the sprite of the active player.
     */
    public void flourish(){
        this.rotate();
        this.rescale();
    }
}