package com.example.cloudsandcables.GUIObjects;

import java.util.ArrayList;
import java.util.HashMap;

import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class RollControls extends VBox {
    private RollButton rollButton = new RollButton();
    private ImageView dieView;
    private int outcome = 1;
    private HashMap<Integer, Image> dieMap;
    private ArrayList<PauseTransition> pauseTransitions;

    /**
     * Constructor for RollControls. Sets layout parameters and loads images
     */
    public RollControls() {
        this.setAlignment(Pos.CENTER);
        this.setPadding(new Insets(20, 20, 20, 20));
        this.setSpacing(10);
        this.dieMap = new HashMap<Integer, Image>();
        this.dieView = new ImageView();
        this.pauseTransitions = new ArrayList<PauseTransition>();
        populateDieMap();
        populatePauseTransitions();
        this.getChildren().addAll(rollButton, dieView);
    }

    public RollButton getRollButton() {
        return this.rollButton;
    }

    public int getOutcome() {
        return this.outcome;
    }

    public void setOutcome(int outcome) {
        this.outcome = outcome;
    }

    /**
     * Changes die face to match the outcome of the roll, cycling through several faces in animation.
     * @param outcome of the roll is stored in RollControls.
     */
    public void update(int outcome) {
        this.outcome = outcome; // Store the outcome.
        // We cycle over all our pauseTransitions (durations), save for the last one.
        final int[] previousFace = {0}; // We have to initialize this value in an array because lambda expressions are stupid.
        for (int i = 0; i < pauseTransitions.size() - 1; i++) {
            final int index = i; // Index has to be final >:(
            if (i == 0) { // On first loop...
                pauseTransitions.get(0).play(); // Trigger the first timing event:
            }
            pauseTransitions.get(index).setOnFinished(e -> {
                /* This code allows us to emulate the rolling of a die's bouncing around 
                by showing a new die face on each cycle. */
                int face = roll(); // Roll for a random number
                while (face == previousFace[0]) // If that roll matches the previous roll...
                    face = roll(); // Reroll
                this.dieView.setImage(dieMap.get(face)); // randomize the die image
                previousFace[0] = face; // Update the previous die face
                pauseTransitions.get(index + 1).play(); // and trigger the next pauseTransition
            });
        }
        // The final pauseTransition reveals the outcome of the die roll.
        pauseTransitions.get(pauseTransitions.size() - 1).setOnFinished(e -> {
            this.dieView.setImage(dieMap.get(outcome)); // The final outcome is displayed
        });

    }

    /**
     * Simple die roll function
     * @return number between 1 and 6
     */
    public int roll() {
        int roll = (int) (Math.random() * 6) + 1;
        return roll;
    }

    /**
     * Loads images of die faces.
     */
    public void populateDieMap() {
        // Local path is not ideal.
        String path = "C:\\Users\\BaisOlivier(Calco)\\JavaProject\\CloudsAndCables\\CloudsAndCables\\src\\main\\java\\com\\example\\cloudsandcables\\images\\die";
        for (int i = 1; i < 7; i++) {
            this.dieMap.put(i, new Image(path + i + ".png")); // Concatenate strings to extract each color.
        }
    }

    /**
     * Populates the pause transitions ArrayList with a sequence of increasing millisecond durations
     */
    public void populatePauseTransitions() {
        int time = 16;
        for (int i = 0; i < 7; i++) {
            this.pauseTransitions.add(new PauseTransition(Duration.millis(time)));
            time += 32;
        }
    }
}
