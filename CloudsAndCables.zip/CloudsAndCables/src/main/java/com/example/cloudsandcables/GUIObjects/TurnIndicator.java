package com.example.cloudsandcables.GUIObjects;

import com.example.cloudsandcables.objects.Player;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class TurnIndicator extends VBox{
    private Label turnLabel = new Label("Turn: ");
    private Label playerLabel = new Label("noname_error");

public TurnIndicator(){
    this.getChildren().addAll(turnLabel, playerLabel);
    this.setPadding(new Insets(20, 20, 20, 20));
    this.setMinSize(50, 70);
}
/**
 * Update the player turn field to display the player whose turn it is. Must be called on Continue Button press and at the ends of turns.
 * @param playerName player name, extracted from Player.getName()
 */
public void update(Player player){
    this.playerLabel.setText(player.getName());
    this.playerLabel.setTextFill(player.getColorObject());
}

}
