package com.example.cloudsandcables.GUIObjects;

import java.util.HashMap;

import com.example.cloudsandcables.objects.GridPos;
import com.example.cloudsandcables.objects.Player;
import com.example.cloudsandcables.objects.PlayerSprite;

import javafx.geometry.*;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

public class Board extends GridPane {
    private int boardSize;
    private GridPane gridPane;
    private HashMap<Integer, Integer> numOccupants;
    public HashMap<Integer, GridPos> gridPosMap;
    private int numPlayers;
    public HashMap<Integer, Integer> cloudsMap;
    public HashMap<Integer, Integer> cablesMap;

    // Constructor
    public Board(int boardSize, int numPlayers) {
        this.boardSize = boardSize;
        this.gridPosMap = new HashMap<Integer, GridPos>();
        this.numOccupants = new HashMap<Integer, Integer>();
        // Set layout settings
        this.setPadding(new Insets(20, 20, 20, 30));
        this.setHgap(10);
        this.setVgap(20);
        this.setMinSize(500, 550);
        this.setAlignment(Pos.CENTER);
        this.numPlayers = numPlayers;
        this.cloudsMap = new HashMap<>();
        populateCloudsMap();
        this.cablesMap = new HashMap<>();
        populateCablesMap();
    }

    // Getters
    public int getBoardSize() {
        return this.boardSize;
    }

    // Setters
    public void setBoardSize(int boardSize) {
        this.boardSize = boardSize;
    }

    /** Populate the board with board numbers */
    public void populateBoard() {
        // Position 'pos' is our position indexer; the square of the board size.
        int pos = (int) Math.pow((double) boardSize, 2);
        for (int row = 0; row < boardSize; row++) { // Loop over rows
            if (row % 2 == 0) { // On even rows...
                for (int col = 0; col < boardSize; col++) { // loop over columns
                    Label posLabel = new Label(String.valueOf(pos)); // Make label,
                    this.setConstraints(posLabel, col, row); // set position,
                    this.getChildren().add(posLabel); // add label
                    // Update hashmaps with grid data:
                    GridPos gridPos = new GridPos(col, row); // make object bearing grid position coordinates (c,r)
                    this.gridPosMap.put(pos, gridPos); // add it to the hashMap with positions and c-r-coordinates
                    this.numOccupants.put(pos, 0); // populate hashmap with number of occupants per grid pos., starting
                                                   // at 0
                    // Lock column width:
                    ColumnConstraints columnConstraint = new ColumnConstraints();
                    columnConstraint.setPrefWidth(40);
                    this.getColumnConstraints().add(columnConstraint);
                    pos--; // count down the board position iterator
                }
            } else {
                // counting down. This way, the numbers snake around the board.
                for (int col = boardSize; col > 0; col--) { // On uneven rows, we do the same, but
                    Label posLabel = new Label(String.valueOf(pos)); // Same steps as before.
                    this.setConstraints(posLabel, col - 1, row); // We index column - 1, or things will be misaligned.
                    this.getChildren().add(posLabel);
                    GridPos gridPos = new GridPos(col - 1, row);
                    this.gridPosMap.put(pos, gridPos);
                    this.numOccupants.put(pos, 0);
                    ColumnConstraints columnConstraint = new ColumnConstraints();
                    columnConstraint.setPrefWidth(40);
                    this.getColumnConstraints().add(columnConstraint);
                    pos--;
                }
            }
            // Lock row height:
            RowConstraints rowConstraint = new RowConstraints();
            rowConstraint.setPrefHeight(35);
            this.getRowConstraints().add(rowConstraint);

        }
    }
    /**
     * Gets the position as an array of row and column
     * @param position number on the board
     * @return array of size 2, containing the row and the column
     */
    public int[] getPos(int position) {
        gridPosMap.get(position);
        GridPos extractedGridPos = this.gridPosMap.get(position);
        int[] rowColumn = { extractedGridPos.getRow(), extractedGridPos.getColumn() };
        return rowColumn;
    }
    /**
     * Places player sprites on the board depending on chosen number of players
     * @param player1Sprite
     * @param player2Sprite
     * @param player3Sprite
     * @param player4Sprite
     * @param numPlayers
     */
    public void placeSpritesOnBoard(PlayerSprite player1Sprite, PlayerSprite player2Sprite, PlayerSprite player3Sprite,
            PlayerSprite player4Sprite, int numPlayers) {
        if (numPlayers >= 1) {
            this.getChildren().add(player1Sprite);
            this.setConstraints(player1Sprite, this.getPos(1)[0], this.getPos(1)[1]);
        }
        if (numPlayers >= 2) {
            this.getChildren().add(player2Sprite);
            this.setConstraints(player2Sprite, this.getPos(1)[0], this.getPos(1)[1]);
        }
        if (numPlayers >= 3) {
            this.getChildren().add(player3Sprite);
            this.setConstraints(player3Sprite, this.getPos(1)[0], this.getPos(1)[1]);
        }
        if (numPlayers == 4) {
            this.getChildren().add(player4Sprite);
            this.setConstraints(player4Sprite, this.getPos(1)[0], this.getPos(1)[1]);
        }

    }
    /**
     * Moves selected player sprite to the chosen position
     * @param playerSprite
     * @param position
     */
    public void moveSprite(PlayerSprite playerSprite, int position) {
        int row = getPos(position)[0];
        int col = getPos(position)[1];
        this.setConstraints(playerSprite, row, col);
    }
    /**
     * Checks if player finds themselves on bottom of cloud.
     * @param player
     * @return true if player is on bottom of cloud.
     */
    public boolean onCloud(Player player) {
        if (this.cloudsMap.containsKey(player.getPosition()))
            return true;
        else
            return false;
    }
    /**
     * Moves player and player sprite to top of cloud
     * @param player
     * @param playerSprite
     * @return destination position, for the terminal to display
     */
    public int climbCloud(Player player, PlayerSprite playerSprite) {
        int destination = this.cloudsMap.get(player.getPosition());
        player.setPosition(destination);
        int row = getPos(destination)[0];
        int col = getPos(destination)[1];
        this.setConstraints(playerSprite, row, col);
        playerSprite.cloudDance(); // does a lil dance
        return destination;
    }
    /**
     * Checks if player is on top of cable
     * @param player
     * @return true if player is on top of cable
     */
    public boolean onCable(Player player) {
        if (this.cablesMap.containsKey(player.getPosition()))
            return true;
        else
            return false;
    }
    /**
     * Brings player and their sprite to bottom of cable
     * @param player
     * @param playerSprite
     * @return cable destination, for the terminal to report
     */
    public int descendCable(Player player, PlayerSprite playerSprite) {
        int destination = this.cablesMap.get(player.getPosition());
        player.setPosition(destination);
        int row = getPos(destination)[0];
        int col = getPos(destination)[1];
        this.setConstraints(playerSprite, row, col);
        playerSprite.cableDance();
        return destination;
    }
    /**
     * Adds clouds and destinations to hashmap
     */
    public void populateCloudsMap() {
        this.cloudsMap.put(1, 38);
        this.cloudsMap.put(4, 14);
        this.cloudsMap.put(8, 30);
        this.cloudsMap.put(21, 42);
        this.cloudsMap.put(28, 76);
        this.cloudsMap.put(50, 67);
        this.cloudsMap.put(71, 92);
        this.cloudsMap.put(80, 99);
    }
    /**
     * Adds cables and destinations to hashmap
     */
    public void populateCablesMap() {
        this.cablesMap.put(97, 78);
        this.cablesMap.put(95, 56);
        this.cablesMap.put(88, 24);
        this.cablesMap.put(62, 18);
        this.cablesMap.put(48, 26);
        this.cablesMap.put(36, 6);
        this.cablesMap.put(32, 10);
    }
    /** Pauses the main thread for 1 second. */
    public static void sleep() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}