package com.example.cloudsandcables.objects;



import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;

public class Player {
    private int playerNum;
    private String name;
    private String color;
    private int position;
    private int FINAL_TILE = Constants.FINAL_TILE;
    private Label icon;

// constructor
    public Player(int playerNum, String name, String color, int position) {
        this.setPlayerNum(playerNum);
        this.setName(name);
        this.setColor(color);
        this.setPosition(position);
        this.icon = new Label("P" + String.valueOf(playerNum));
    }
// copy constructor
    public Player(Player source) {
        this.setPlayerNum(source.getPlayerNum());
        this.setName(source.getName());
        this.setColor(source.getColor());
        this.setPosition(source.getPosition());
        this.icon = new Label("P" + String.valueOf(this.playerNum));
    }

// getters and setters
    public int getPlayerNum() {
        return playerNum;
    }
    public String getName() {
        return name;
    }
    public String getColor() {
        return color;
    }
    public int getPosition() {
        return position;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public void setPlayerNum(int playerNum) {
        this.playerNum = playerNum;
    }
    public void setPosition(int position) {
        this.position = position;
    }

    //TODO: We have player color objects now. Now I need to color the actual icons.
    /**
     * Takes as input a color as a string and returns it as a JavaFX Color class.
     * We can select from the following colors: "Red", "Green", "Blue", "Yellow", "Black", "White", "Pink", "Brown", "Orange", "Purple", "Gray"
     * @param color the color chosen, as a string
     * @return a JavaFX color object.
     */
    public Color getColorObject() {
        switch (this.getColor()) {
            case "Red":
                return Color.RED;
            case "Green":
                return Color.GREEN;
            case "Blue":
                return Color.BLUE;
            case "Yellow":
                return Color.YELLOW;
            case "Black":
                return Color.BLACK;
            case "White":
                return Color.WHITE;
            case "Pink":
                return Color.PINK;
            case "Brown":
                return Color.BROWN;
            case "Orange":
                return Color.CORAL;
            case "Purple":
                return Color.PURPLE;
            case "Gray":
                return Color.GRAY;
            default:
                return Color.BLACK;
        }
    }
// methods
    public int rollDie() {
        int roll = (int) (Math.random() * 6) + 1; // Simulates rolling a dice (1-6)
        System.out.println("You rolled a " + roll);
        return roll;
    }
    public void move(int steps) {
        this.setPosition(this.getPosition() + steps); // Move the player by the rolled number of steps
        int difference = Math.abs(FINAL_TILE - this.getPosition()); // Calculate the distance between the final tile and the current position
        // First, we simply print a notification if the player's roll is greater than the final tile.
        if (this.position > FINAL_TILE && difference == 1) System.out.println("Uh oh! You have moved past the final tile! You will be moved back " + difference + " space.");
        else if (this.position > FINAL_TILE) System.out.println("Uh oh! You have moved past the final tile! You will be moved back " + difference + " spaces.");
        // Calculate difference between FINAL_TILE and current position
        this.setPosition(FINAL_TILE - difference); // Move the player to the new position
    }

}

