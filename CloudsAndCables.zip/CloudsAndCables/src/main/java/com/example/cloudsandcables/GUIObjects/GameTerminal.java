package com.example.cloudsandcables.GUIObjects;

import javafx.animation.PauseTransition;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class GameTerminal extends VBox {

    public GameTerminal() {
        this.setAlignment(Pos.CENTER_RIGHT);
    }

    public void print(String text) {
        this.getChildren().add(new Label(text));
        if (this.getChildren().size() > 3)
            this.getChildren().removeFirst();
    }

    // public void print(String text) {
    //     PauseTransition pause = new PauseTransition(Duration.millis(666));
    //     pause.setOnFinished(event -> {
    //         this.getChildren().add(new Label(text));
    //         if (this.getChildren().size() > 3)
    //         this.getChildren().removeFirst();
    //     });
    //     pause.play();
    // }

    // Main thread sleeps for 1000ms
    public static void sleep() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
