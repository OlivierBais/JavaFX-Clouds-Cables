package com.example.cloudsandcables.GUIObjects;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.example.cloudsandcables.objects.GridPos;
import com.example.cloudsandcables.objects.Player;
import com.example.cloudsandcables.objects.PlayerIcon;

import javafx.geometry.*;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;

public class Board extends GridPane {
    private int boardSize;
    private GridPane gridPane;
    private HashMap<Integer, Integer> numOccupants;
    public HashMap<Integer, GridPos> gridPosMap;
    private int numPlayers;

    // Constructor
    public Board(int boardSize, int numPlayers) {
        this.boardSize = boardSize;
        this.gridPosMap = new HashMap<Integer, GridPos>();
        this.numOccupants = new HashMap<Integer, Integer>();
        // Set layout settings
        this.setPadding(new Insets(20, 20, 20, 20));
        this.setHgap(20);
        this.setVgap(20);
        this.setMinSize(500, 950);
        this.setAlignment(Pos.CENTER);
        this.numPlayers = numPlayers;
    }

    // Getters
    public int getBoardSize() {
        return this.boardSize;
    }

    // Setters
    public void setBoardSize(int boardSize) {
        this.boardSize = boardSize;
    }

    /** Populate the board with board numbers */
    public void populateBoard() {
        // Position 'pos' is our position indexer; the square of the board size.
        int pos = (int) Math.pow((double) boardSize, 2);
        for (int row = 0; row < boardSize; row++) { // Loop over rows
            if (row % 2 == 0) { // On even rows...
                for (int col = 0; col < boardSize; col++) { // loop over columns
                    Label posLabel = new Label(String.valueOf(pos)); // Make label,
                    this.setConstraints(posLabel, col, row); // set position,
                    this.getChildren().add(posLabel); // add label
                    // Update hashmaps with grid data:
                    GridPos gridPos = new GridPos(col, row); // make object bearing grid position coordinates (c,r)
                    this.gridPosMap.put(pos, gridPos); // add it to the hashMap with positions and c-r-coordinates
                    this.numOccupants.put(pos, 0); // populate hashmap with number of occupants per grid pos., starting at 0
                    // Lock column width:
                    ColumnConstraints columnConstraint = new ColumnConstraints(); 
                    columnConstraint.setPrefWidth(40);
                    this.getColumnConstraints().add(columnConstraint);
                    pos--; // count down the board position iterator
                }
            } else {
                // counting down. This way, the numbers snake around the board.
                for (int col = boardSize; col > 0; col--) { // On uneven rows, we do the same, but
                    Label posLabel = new Label(String.valueOf(pos)); // Same steps as before.
                    this.setConstraints(posLabel, col - 1, row); // We index column - 1, or things will be misaligned.
                    this.getChildren().add(posLabel);
                    GridPos gridPos = new GridPos(col - 1, row);
                    this.gridPosMap.put(pos, gridPos);
                    this.numOccupants.put(pos, 0);
                    ColumnConstraints columnConstraint = new ColumnConstraints();
                    columnConstraint.setPrefWidth(40);
                    this.getColumnConstraints().add(columnConstraint);
                    pos--;
                }
            }
            // Lock row height:
            RowConstraints rowConstraint = new RowConstraints();
            rowConstraint.setPrefHeight(35);
            this.getRowConstraints().add(rowConstraint);
        }
    }

    public int[] getPos(int position) {
        gridPosMap.get(position);
        GridPos extractedGridPos = this.gridPosMap.get(position);
        int[] rowColumn = { extractedGridPos.getRow(), extractedGridPos.getColumn() };
        return rowColumn;
    }

    public void moveIcon(PlayerIcon playerIcon, int position){
        int row = getPos(position)[0];
        int col = getPos(position)[1];
        this.setConstraints(playerIcon, row, col);
    }

}