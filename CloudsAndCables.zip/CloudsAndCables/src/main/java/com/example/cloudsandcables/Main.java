package com.example.cloudsandcables;

import javafx.animation.PauseTransition;
// IMPORTS
import javafx.application.Application;
import javafx.collections.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.ArrayList;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

import com.example.cloudsandcables.GUIObjects.*;
import com.example.cloudsandcables.objects.*;

//MAIN
public class Main extends Application {
    // DEBUG MODE: Set this to true to skip the player selection screen and the
    // close window warning
    boolean debugMode = false;

    // SECTION 0: Initialize objects
    // Initialize version names
    static String cacVersion = "2.2";
    static String editionName = "Animated Edition";
    // Initialize booleans for debug mode
    boolean skipPlayerSelect = false;
    boolean enableWarning = true;
    // Initialize window and layouts
    Stage window;
    BorderPane layout;
    VBox playerSelectionLayout = new VBox();
    VBox gameLayout = new VBox();
    // Initialize scenes
    Scene playerSelectionScene = new Scene(playerSelectionLayout, 400, 700); // Set the scene
    Scene gameScene = new Scene(gameLayout, 550, 750); // Set the scene for the game
    // Initialize players and player-related objects
    int numPlayers = 2;
    Players players = new Players();
    PlayerSprite player1Sprite = new PlayerSprite();
    PlayerSprite player2Sprite = new PlayerSprite();
    PlayerSprite player3Sprite = new PlayerSprite();
    PlayerSprite player4Sprite = new PlayerSprite(); 
    ArrayList<PlayerSprite> playerSprites = new ArrayList<>();
    int activePlayer = 0;
    // Initialize UI objects
    ComboBox<Integer> playerNumberSelector;
    HBox controlsHBox = new HBox();
    TurnIndicator turnIndicator = new TurnIndicator();
    RollControls rollControls = new RollControls();
    GameTerminal gameTerminal = new GameTerminal();

    // Initialize pause timers
    PauseTransition pauseTurnReport = new PauseTransition(Duration.millis(600));
    PauseTransition pauseCloudCable = new PauseTransition(Duration.millis(2000));
    PauseTransition pauseNonEvent = new PauseTransition(Duration.millis(600));
    PauseTransition waitForRoll = new PauseTransition(Duration.millis(1300));
    int boardSize = 10;

    // Application launcher
    public static void main(String[] args) {
        launch(args);
    }

    // Application starter, the true 'main' of the application.
    @Override
    public void start(Stage mainStage) throws Exception {
        // Debug Mode logic
        setDebugMode(debugMode);
        // Window settings
        mainStage.setTitle("Clouds & Cables " + cacVersion + ": " + editionName + " Edition"); // Set window title
        playerSelectionScene.getStylesheets().add("CloudsAndCablesTheme.css");
        gameScene.getStylesheets().add("CloudsAndCablesTheme.css");
        // LAYOUT CONSTRUCTION
        // 1. Array of nodes containing player settings screens (name and col)
        PlayerVBox[] playerVBoxes = populatePlayerSelectionLayout(playerSelectionLayout, mainStage);
        // 2. Exit + continue button; Continue button logic
        Button continueButton = addExitContinueButton(mainStage, playerSelectionLayout, enableWarning);
        // 3. board creation
        Board board = new Board(boardSize, numPlayers);
        Pane boardPane = addBoardImage(board);
        // Populate board with position numbers
        board.populateBoard();
        ExitButton exitButton = new ExitButton("Quit", mainStage);
        exitButton.setAlignment(Pos.CENTER_RIGHT);
        exitButton.setHgrow(exitButton, Priority.ALWAYS);
        HBox headerGraphic = createHeaderGraphic();
        // Continue button logic
        continueButton.setOnAction(e -> {
            Players savedPlayers = handleContinueButton(mainStage, gameScene, playerVBoxes, board); // Player settings are stored
            players.setPlayers(savedPlayers, numPlayers); // Excess players removed
            board.placeSpritesOnBoard(player1Sprite, player2Sprite, player3Sprite, player4Sprite, numPlayers); // Objects containing sprites are stored in board
            setPlayerSprites(); // Sprites themselves assigned, based on player color
        });
        hidePlayerSprites(); // Hide player sprites on turn 0
        // SECTION 3//
        // Turn logic: triggered when the 'roll' button is pressed.
        rollControls.getRollButton().setOnAction(e -> {
            // roll die and display in 'rollControls' window; will be an image later.
            int roll = rollControls.roll();
            rollControls.update(roll);
            // Move player, and return 'true' if their position exceeds 100
            waitForRoll.play();
            waitForRoll.setOnFinished(afterRoll -> {
                if (!playerSprites.get(activePlayer).isVisible()) { // If the active player is not yet visible
                    playerSprites.get(activePlayer).setVisible(true); // Make them visible
                }
                boolean overextended = players.move(activePlayer, roll);
                // Check if player is on top of cloud or bottom of cable.
                boolean onCloud = (board.onCloud(players.getPlayer(activePlayer)));
                boolean onCable = (board.onCable(players.getPlayer(activePlayer)));
                // Move player sprite initially, i.e. before cloud/cable handling
                board.moveSprite(playerSprites.get(activePlayer), players.getPosition(activePlayer));
                // Print terminal message for player movement, factoring in the 'overextended' case:
                printMovementMessages(overextended);
                // On non-events, we change turns at a quick rate, without special logic:
                pauseNonEvent.setOnFinished(nonevent -> {
                    changeActivePlayer(false);
                });
                // On events, we give players time to process before handling the event at a slow pace:
                pauseCloudCable.setOnFinished(event -> {
                    handleCloudCable(board); // Move player up or down the cloud/cable
                    changeActivePlayer(true);
                });
                if (onCloud) { // If on cloud, print a message and invoke sprite movement + cloud handling after a delay.
                    gameTerminal.print("Hurray! " + players.getName(activePlayer) + " landed on a cloud!"); // print message
                    pauseCloudCable.play();
                } else if (onCable) { // Same with cables.
                    gameTerminal.print("Oh no! " + players.getName(activePlayer) + " landed on a cable!");
                    pauseCloudCable.play();
                } else // Otherwise, invoke turn switch under normal circumstances.
                    pauseNonEvent.play();
            });
        });
        controlsHBox.getChildren().addAll(turnIndicator, rollControls, gameTerminal, exitButton);
        // SECTION 4//
        // Footer with exit button, and later, concede button.
        HBox footerHBox = new HBox();
        // Add elements to main layout and set scene
        gameLayout.getChildren().addAll(headerGraphic, boardPane, controlsHBox, footerHBox);
        // Preparatory code for launching the game itself:
        mainStage.show(); // Show window
        mainStage.setScene(playerSelectionScene);
    }

    // FUNCTIONS
    /**
     * Creates Player settings VBox.
     * 
     * @param playerNum player number for the player to be created, e.g. player 1, player 2
     * @return a VBox with the player settings fields: a label, name text field, and
     *         color selector
     */
    public VBox createPlayerSettings(int playerNum) {
        Label playerNumLabel = new Label("Player " + playerNum);
        VBox playerVBox = new VBox();
        playerVBox.getChildren().addAll(playerNumLabel);
        return playerVBox;
    }

    /**
     * Populates the player number selector HBox, and contains the logic that
     * follows from changing the number of players
     * 
     * @param playerNumberHBox   is the Hbox that will contain the player number
     * @param playerSettingsHBox is the HBox that contains player settings VBoxes,
     *                           where players insert their name and color.
     * @return
     */
    public ComboBox<Integer> populatePlayerNumberHBox(HBox playerNumberHBox, HBox playerSettingsHBox) {
        Label playersLabel = new Label("Players: "); // Label for player number
        ObservableList<Integer> playerNumbers = FXCollections.observableArrayList(1, 2, 3, 4); // List of possible
                                                                                               // player numbers, 1-4
        ComboBox<Integer> playerNumberSelector = new ComboBox<>(playerNumbers); // Create a dropdown box with the player
                                                                                // numbers
        playerNumberSelector.setValue(numPlayers);
        playerNumberHBox.getChildren().addAll(playersLabel, playerNumberSelector); // Add the label and dropdown box
        playerNumberHBox.setAlignment(Pos.CENTER); // Center the HBox
        return playerNumberSelector;
    }

    /**
     * Populates the Hbox containing player settings (name, color), as well as their
     * reaction to changing the number of player.
     * 
     * @param playerSettingsHBox is the HBox to be filled with four player settings
     *                           VBoxes
     * @return the VBoxes, from which we will extract player information once the
     *         Continue Button is clicked.
     */
    public PlayerVBox[] populatePlayerSettingsHBox(HBox playerSettingsHBox) {
        // Create a settings selection element (PlayerVBox) for each player, with
        // default parameters:
        PlayerVBox player1VBox = new PlayerVBox(1, "Ed", "Red");
        PlayerVBox player2VBox = new PlayerVBox(2, "Gene", "Green");
        PlayerVBox player3VBox = new PlayerVBox(3, "Lou", "Blue");
        PlayerVBox player4VBox = new PlayerVBox(4, "Jack", "Black");
        // We default to two players. So players 3 and 4 are disabled unless the user
        // changes the selection:
        player3VBox.disable();
        player4VBox.disable();
        // Add the PlayerVBoxes to the playerSettingsHBox
        playerNumberSelector
                .setOnAction(e -> {
                    numPlayers = handleNumPlayerChange(player1VBox, player2VBox, player3VBox, player4VBox);
                });
        playerSettingsHBox.getChildren().addAll(player1VBox, player2VBox, player3VBox, player4VBox);
        PlayerVBox[] playerVBoxes = { player1VBox, player2VBox, player3VBox, player4VBox };
        return playerVBoxes;
    }

    /**
     * Handles all logic for when the player number dropdown box is changed.
     * Inelegant but effective.
     * 
     * @param player1VBox
     * @param player2VBox
     * @param player3VBox
     * @param player4VBox
     */
    public int handleNumPlayerChange(PlayerVBox player1VBox, PlayerVBox player2VBox, PlayerVBox player3VBox,
            PlayerVBox player4VBox) {
        int numPlayers = playerNumberSelector.getValue(); // Store the newly changed number of players.
        // We use a switch case to disable or enable the player settings VBoxes based on
        // the number of players selected.
        switch (numPlayers) {
            case 1:
                player1VBox.enable();
                player2VBox.disable();
                player3VBox.disable();
                player4VBox.disable();
                return numPlayers;
            case 2:
                player1VBox.enable();
                player2VBox.enable();
                player3VBox.disable();
                player4VBox.disable();
                return numPlayers;
            case 3:
                player1VBox.enable();
                player2VBox.enable();
                player3VBox.enable();
                player4VBox.disable();
                return numPlayers;
            case 4:
                player1VBox.enable();
                player2VBox.enable();
                player3VBox.enable();
                player4VBox.enable();
                return numPlayers;
            default:
                player1VBox.enable();
                player2VBox.disable();
                player3VBox.disable();
                player4VBox.disable();
                return numPlayers;
        }
    }

    /**
     * Populate the player selection layout with a welcome screen, version
     * indicator, and fields for player number and player settings.
     * 
     * @param playerSelectionLayout is the layout which will hold the elements of
     *                              the player selection screen
     * @param stage                 is the stage onto which the layout will be
     *                              placed
     * @return PlayerVBox[], an array of VBoxes containing the player settings
     *         fields from which we will extract information.
     */
    public PlayerVBox[] populatePlayerSelectionLayout(VBox playerSelectionLayout, Stage stage) {
        Label welcomeLogoPlaceholder = new Label(
                "*PLACEHOLDER* Welcome to Clouds & Cables Version " + cacVersion + "!"); // Welcome image goes here.
        Image logo = new Image(
                "C:\\Users\\BaisOlivier(Calco)\\JavaProject\\CloudsAndCables\\CloudsAndCables\\src\\main\\java\\com\\example\\cloudsandcables\\images\\logo.png");
        ImageView logoView = new ImageView(logo);
        Label howManyPlayers = new Label("How many players are you?");
        HBox playerNumberHBox = new HBox(); // Create empty HBox that will contain player number selector
        HBox playerSettingsHBox = new HBox(); // Create empty HBox for player settings interface
        // Now to populate these layout objects with UI elements
        // Populate playerNumberHBox with UI elements, and store the selected num of
        // players:
        playerNumberSelector = populatePlayerNumberHBox(playerNumberHBox, playerSettingsHBox);
        // Populate player settings HBox with player settings VBoxes; store player
        // settings VBoxes in a non-deep-copied array for access from main:
        PlayerVBox[] playerVBoxes = populatePlayerSettingsHBox(playerSettingsHBox);

        // Test button for debugging. Normally disabled.
        Button testButton = new Button("Test");
        // testButton.setOnAction();
        // Layout configuration
        playerSelectionLayout.getChildren().addAll(logoView, howManyPlayers, playerNumberHBox,
                playerSettingsHBox);
        playerSelectionLayout.setSpacing(10); // Set spacing between elements
        playerSelectionLayout.setAlignment(Pos.CENTER);
        return playerVBoxes;
    }

    /**
     * Create exit button and continue button
     * 
     * @param mainStage             must be passed on so that the exit button can
     *                              fulfill its purpose
     * @param playerSelectionLayout is the grand layout to which the buttons are
     *                              added
     * @return the continue button is returned so that its on-click event can be
     *         handled from Main.
     */
    public Button addExitContinueButton(Stage mainStage, VBox playerSelectionLayout, boolean enableWarning) {
        // Make exit button, as defined in GUIObjects
        ExitButton exitButton = new ExitButton("Exit", mainStage, enableWarning);
        Button continueButton = new Button("Continue"); // Make continue button. Handled in main.
        HBox exitContinueHBox = new HBox(exitButton, continueButton); // HBox contains buttons
        exitContinueHBox.setAlignment(Pos.CENTER); // layout settings
        exitContinueHBox.setSpacing(10);
        playerSelectionLayout.getChildren().add(exitContinueHBox); // Add HBox with buttons to grand layout
        return continueButton; // Pass continue button to main where it can be handled.
    }

    /**
     * Creates an arrayList containing our max. 4 Player objects. Called upon by the
     * 'continue' button.
     * 
     * @param playerVBoxes Vboxes wherein the user filled in player details
     * @return arrayList containing max. 4 Player objects
     */
    public Players createPlayers(PlayerVBox[] playerVBoxes) {
        ArrayList<Player> playersList = new ArrayList<>();
        for (int i = 0; i < numPlayers; i++) { // Loop over the selected number of players
            int playerNumber = playerVBoxes[i].getPlayerNum(); // Get inserted info from Player VBoxes
            String playerName = playerVBoxes[i].getPlayerName();
            String playerColor = playerVBoxes[i].getPlayerColor();
            // Construct player based on gotten info, and add to the arrayList.
            Player tempPlayer = new Player(playerNumber, playerName, playerColor, 0);
            playersList.add(tempPlayer);
        }
        numPlayers = playersList.size();
        Players tempPlayers = new Players(playersList, numPlayers);
        return tempPlayers;
    }

    /**
     * Dev mode. Disables the warning screen.
     * 
     * @param debugMode
     */
    public void setDebugMode(boolean debugMode) {
        if (debugMode) {
            skipPlayerSelect = true;
            enableWarning = false;
            pauseTurnReport = new PauseTransition(Duration.millis(0));
        }
    }

    /**
     * Logic for handling the continue button, which triggers player creation.
     * 
     * @param mainStage    Stage on which all scenes are placed.
     * @param gameScene    Scene which holds the game board and controls
     * @param playerVBoxes Layout elements into which player settings will be filled
     * @param board        Board on which the game is played
     * @return tempPlayers, a Players object containing all our players with the
     *         right settings.
     */
    public Players handleContinueButton(Stage mainStage, Scene gameScene, PlayerVBox[] playerVBoxes, Board board) {
        mainStage.setScene(gameScene); // Switch scenes
        // Create players from the filled-in VBoxes.
        Players tempPlayers = createPlayers(playerVBoxes);
        turnIndicator.update(tempPlayers.getPlayer(0));
        tempPlayers.printSettings(numPlayers);
        return tempPlayers;
    }

    /**
     * Creates the header graphic. For now, it has a text placeholder.
     * 
     * @return
     */
    public HBox createHeaderGraphic() {
        // Label headerGraphicPlaceholder = new Label("Clouds & Cables");
        Image headerImage = new Image("C:\\Users\\BaisOlivier(Calco)\\JavaProject\\CloudsAndCables\\CloudsAndCables\\src\\main\\java\\com\\example\\cloudsandcables\\images\\header.png");
        ImageView headerImageView = new ImageView(headerImage);
        HBox headerGraphic = new HBox(headerImageView);
        headerGraphic.setPadding(new Insets(10, 5, 0, 5));
        headerGraphic.setAlignment(Pos.CENTER);
        headerGraphic.setSpacing(10);
        return headerGraphic;
    }

    /**
     * Populates player sprites depending on the selected number of players.
     */
    public void setPlayerSprites() {
        if (numPlayers >= 1) {
            playerSprites.add(player1Sprite);
            player1Sprite.setSpriteValues(players.getColor(0), 1);
        }
        if (numPlayers >= 2) {
            playerSprites.add(player2Sprite);
            player2Sprite.setSpriteValues(players.getColor(1), 2);
        }
        if (numPlayers >= 3) {
            playerSprites.add(player3Sprite);
            player3Sprite.setSpriteValues(players.getColor(2), 3);
        }
        if (numPlayers >= 4) {
            playerSprites.add(player4Sprite);
            player4Sprite.setSpriteValues(players.getColor(3), 4);
        }
    }

    public void hidePlayerSprites() {
        player1Sprite.setVisible(false);
        player2Sprite.setVisible(false);
        player3Sprite.setVisible(false);
        player4Sprite.setVisible(false);
    }

    // Main thread sleeps for 1000ms
    public static void sleep() {
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void printMovementMessages(boolean overextended) {
        if (overextended)
            gameTerminal.print("Oh no! " + players.getName(activePlayer)
                    + " rolled too high, and looped back to position " + players.getPosition(activePlayer) + "!");
        else
            gameTerminal
                    .print(players.getName(activePlayer) + " moved to " + players.getPosition(activePlayer) + ".");
        if (players.getPosition(activePlayer) == 100) {
            gameTerminal.print(players.getName(activePlayer) + " wins!!!");
        }
    }

    /**
     * Populates board with the board pixelart image and aligns it with the tile
     * number grid.
     * 
     * @param board
     * @return the pane on which the board image was placed.
     */
    public Pane addBoardImage(Board board) {
        Image boardImage = new Image(
                "C:\\Users\\BaisOlivier(Calco)\\JavaProject\\CloudsAndCables\\CloudsAndCables\\src\\main\\java\\com\\example\\cloudsandcables\\images\\cloudsCablesBoardImgV2.png");
        ImageView boardImageView = new ImageView(boardImage);
        // The boardPane holds the board and the image atop each other.
        Pane boardPane = new Pane();
        boardImageView.setX(30);
        boardImageView.setY(30);
        boardPane.getChildren().addAll(boardImageView, board);
        return boardPane;
    }

    /**
     * Handles the logic that happens if a player lands on a cloud or cable
     * 
     * @param board on which the game is played
     */
    public void handleCloudCable(Board board) {
        if (board.onCloud(players.getPlayer(activePlayer))) { // If a player finds themselves on a cloud
            board.climbCloud(players.getPlayer(activePlayer), playerSprites.get(activePlayer)); // move player
            gameTerminal.print(players.getName(activePlayer) + " migrated to position " // print move message
                    + players.getPosition(activePlayer) + "!");
        } else if (board.onCable(players.getPlayer(activePlayer))) {
            board.descendCable(players.getPlayer(activePlayer), playerSprites.get(activePlayer));
            gameTerminal.print(players.getName(activePlayer) + " downgraded to position "
                    + players.getPosition(activePlayer) + "!");
        }
    }

    /**
     * Gives turn to next active player, and prints the corresponding message.
     */
    public void changeActivePlayer(boolean onCloudCable) {
        activePlayer += 1;
        if (activePlayer >= numPlayers)
            activePlayer = 0;
        if (onCloudCable) // If player is on cable or cloud, give them time to read the message before
            // switching turns.
            pauseTurnReport.setDuration(Duration.millis(2000));

        else // Else, set the pause timer back to default
            pauseTurnReport.setDuration(Duration.millis(600)); // Print the message
        pauseTurnReport.setOnFinished(event -> printNextTurn()); // Trigger message printing after 2000 OR 600 ms.
        pauseTurnReport.play();
    }

    public void printNextTurn() {
        gameTerminal.print("It is " + players.getName(activePlayer) + "'s turn.");
        turnIndicator.update(players.getPlayer(activePlayer));
        playerSprites.get(activePlayer).flourish();
    }

}
