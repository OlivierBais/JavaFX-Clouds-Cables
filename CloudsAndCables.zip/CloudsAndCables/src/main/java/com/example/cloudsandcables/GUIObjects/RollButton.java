package com.example.cloudsandcables.GUIObjects;

import javafx.scene.control.Button;

public class RollButton extends Button {
    public RollButton(){
        this.setText("Roll");
    }


}
