package com.example.cloudsandcables.objects;

import java.util.ArrayList;

public class Players extends ArrayList {
    public ArrayList<Player> players;
    // Full constructor
    public Players(ArrayList<Player> players, int numPlayers){
        this.players = new ArrayList<Player>();
        for (int i = 0; i < numPlayers; i++) {
            Player tempPlayer = new Player(players.get(i));
            this.players.add(tempPlayer);
        }

    }
    // Empty constructor
    public Players(){
        this.players = new ArrayList<>();
    }

    //Getters and setters
    public Player getPlayer(int index){
        return this.players.get(index);
    }
    //TODO: This must be where the issue lies; the object 'players' is a private field and an arraylist.
    public ArrayList<Player> getPlayers(){
        return this.players;
    }
    /**
     * Setter for a single player
     * @param index in the list of players
     * @param player
     */
    public void setPlayer(int index, Player player){
        this.players.set(index, player);
    }
    /**
     * Setter for all players at once; the number of players specified previously
     * @param players
     * @param numPlayers
     */
    public void setPlayers(Players players, int numPlayers){
        for (int i = 0; i < numPlayers; i++) this.getPlayers().add(players.getPlayer(i));
    }
}
