package com.example.cloudsandcables.objects;

import static com.example.cloudsandcables.objects.Constants.*;

import javafx.scene.control.Label;
import javafx.scene.paint.Paint;

public class PlayerIcon extends Label {
    private String icon;

    public PlayerIcon(int number) {
        this.setText("P" + String.valueOf(number));
        switch (number) {
            case 1:
                this.setPadding(TOP_LEFT);
                break;
            case 2:
                this.setPadding(TOP_RIGHT);
                break;
            case 3:
                this.setPadding(BOTTOM_LEFT);
                break;
            case 4:
                this.setPadding(BOTTOM_RIGHT);
                break;
            default:
                this.setText("ERROR! PLAYER NOT FOUND!");
                break;
        }
    }

    public PlayerIcon() {
        this.setText("");
    }

}
