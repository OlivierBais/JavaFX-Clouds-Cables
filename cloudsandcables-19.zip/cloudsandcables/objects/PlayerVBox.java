package com.example.cloudsandcables.objects;
import javafx.application.Application;
import javafx.collections.*;
import javafx.fxml.FXMLLoader;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.stage.Stage;
import javafx.event.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javafx.scene.control.*;
import javafx.scene.control.cell.*;
import javafx.scene.layout.*;
// PlayerVBox. A VBox with the player number label, name selector, and color selector.
public class PlayerVBox extends VBox {
    // Instance variables
    private Label playerNumLabel;
    private int playerNum;
    private Label playerNameLabel;
    private TextField playerNameField;
    private String playerName;
    private Label playerColorLabel;
    private ComboBox<String> playerColorSelector;
    private String playerColor;

    // Constructor
    public PlayerVBox(int playerNum, String playerName, String playerColor) {
        this.playerNum = playerNum;
        this.playerName = playerName;
        this.playerColor = playerColor;

        // Initialize UI elements
        this.playerNumLabel = new Label("Player " + playerNum);
        this.playerNameLabel = new Label("Name:");
        this.playerNameField = new TextField(playerName);
        this.playerColorLabel = new Label("Color:");
        this.playerColorSelector = new ComboBox<>(FXCollections.observableArrayList("Red", "Green", "Blue", "Yellow", "Black", "White", "Pink", "Brown", "Orange", "Purple", "Gray"));
        this.playerColorSelector.setValue(playerColor);

        // Set up the VBox layout
        this.getChildren().addAll(
            playerNumLabel,
            playerNameLabel,
            playerNameField,
            playerColorLabel,
            playerColorSelector
        );
        this.setSpacing(10); // Set spacing between elements
        this.setPadding(new Insets(10)); // Add padding around the VBox
    }

// This method disables VBox fields
    public void disable() {
        playerNameField.setDisable(true);
        playerColorSelector.setDisable(true);
    }

    public void enable() {
        playerNameField.setDisable(false);
        playerColorSelector.setDisable(false);
    }

    // Getters for the player's information
    public int getPlayerNum() {
        return playerNum;
    }

    public String getPlayerName() {
        return playerNameField.getText();
    }

    public String getPlayerColor() {
        return playerColorSelector.getValue();
    }

}