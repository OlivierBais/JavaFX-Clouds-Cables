package com.example.cloudsandcables.objects;

import static com.example.cloudsandcables.objects.Constants.FINAL_TILE;

import java.util.ArrayList;

import javafx.scene.paint.Color;

public class Players extends ArrayList {
    public ArrayList<Player> players;

    // Full constructor
    public Players(ArrayList<Player> players, int numPlayers) {
        this.players = new ArrayList<Player>();
        for (int i = 0; i < numPlayers; i++) {
            Player tempPlayer = new Player(players.get(i));
            this.players.add(tempPlayer);
        }

    }

    // Empty constructor
    public Players() {
        this.players = new ArrayList<>();
    }

    // Getters and setters
    public Player getPlayer(int index) {
        return this.players.get(index);
    }

    // TODO: This must be where the issue lies; the object 'players' is a private
    // field and an arraylist.
    public ArrayList<Player> getPlayers() {
        return this.players;
    }

    /**
     * Setter for a single player
     * 
     * @param index  in the list of players
     * @param player
     */
    public void setPlayer(int index, Player player) {
        this.players.set(index, player);
    }

    /**
     * Setter for all players at once; the number of players specified previously
     * 
     * @param players
     * @param numPlayers
     */
    public void setPlayers(Players players, int numPlayers) {
        for (int i = 0; i < numPlayers; i++)
            this.getPlayers().add(players.getPlayer(i));
    }

    /**
     * Prints the chosen player settings into the console.
     * 
     * @param numPlayers number of players as selected by user.
     */
    public void printSettings(int numPlayers) {
        for (int i = 0; i < numPlayers; i++) { // Loop over player number and print settings.
            System.out
                    .println("Player " + this.getPlayer(i).getPlayerNum() + " is called " + this.getPlayer(i).getName()
                            + ", and they chose " + this.getPlayer(i).getColor() + ".");
        }
    }

    // "Subgetters and subsetters"; these call the getters and setters contained
    // within the Players objects
    public int getPlayerNum(int playerNum) {
        return this.getPlayer(0).getPlayerNum();
    }

    public String getName(int playerNum) {
        return this.getPlayer(playerNum).getName();
    }

    public String getColor(int playerNum) {
        return this.getPlayer(playerNum).getColor();
    }

    public Color getColorObject(int playerNum) {
        return this.getPlayer(playerNum).getColorObject();
    }

    public int getPosition(int playerNum) {
        return this.getPlayer(playerNum).getPosition();
    }

    public void setName(int playerNum, String name) {
        this.getPlayer(playerNum).setName(name);
    }

    public void setColor(int playerNum, String color) {
        this.getPlayer(playerNum).setColor(color);
    }

    public void setPlayerNum(int playerNum) {
        this.getPlayer(playerNum).setPlayerNum(playerNum);
    }

    public void setPosition(int playerNum, int position) {
        this.getPlayer(playerNum).setPosition(position);
    }
    /**
     * Move the chosen player, accounting for overextension.
     * @param playerNum number of the to-be-moved player
     * @param outcome is the destination to which the player must be moved
     * @return true if the player has moved beyond 100, i.e., they overextended. 
     */
    public boolean move(int playerNum, int outcome) {
        // 'Overextended' is true if the player's position moves above 100.
        boolean overextended = false;
        this.setPosition(playerNum, this.getPosition(playerNum) + outcome); // Move the player by the rolled number of steps
        int difference = Math.abs(FINAL_TILE - this.getPosition(playerNum)); // Calculate the distance between the final tile and
                                                                    // the current position
        if (this.getPosition(playerNum) > FINAL_TILE) overextended = true; // If they move beyond the final tile, we return 'true'
        this.setPosition(playerNum, FINAL_TILE - difference); // Move the player to the new position
        return overextended;
    }
}
