package com.example.cloudsandcables.GUIObjects;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/** Displays a user-interaction-blocking confirm box with a yes- and no-button.
 * Input args: title is the header of the box, and message is the text displayed within.
 * Returns 'answer', a boolean containing the user's response.
 */
public class ConfirmBox {

    static boolean answer; // Initialize answer-storing boolean

    static boolean display(String title, String message){
        // Set window settings
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL); // Blocks user interaction
        window.setTitle(title);
        window.setMinWidth(250);
        // Message label
        Label label = new Label();
        label.setText(message);
        // Create buttons for yes/no
        Button yesButton = new Button("Yes");
        Button noButton = new Button("No");
        // Logic for yes- and no-buttons
        yesButton.setOnAction(e -> {
            answer = true;
            window.close();
        });
        noButton.setOnAction(e -> {
            answer = false;
            window.close();
        });
        // Build scene
        VBox layout = new VBox(10); // Create layout object
        layout.getChildren().addAll(label, yesButton, noButton); // Add objects
        layout.setAlignment(Pos.CENTER); // Align objects to the center
        layout.setPadding(new Insets(10,20,10,20));
        Scene scene = new Scene(layout); // Create scene
        window.setScene(scene); // Attach scene to window
        window.showAndWait(); // Pauses until window is closed

        return answer;
    }
}
