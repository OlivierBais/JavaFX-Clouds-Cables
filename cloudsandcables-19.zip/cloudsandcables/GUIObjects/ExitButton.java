package com.example.cloudsandcables.GUIObjects;

import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import java.io.IOException;
import javafx.scene.control.Label;

// Exit Button with attached logic (Technically, an HBox containing an exit button)
public class ExitButton extends HBox {
    private Button exitButton;
/**
 * Constructor
 * @param text Text displayed in the button
 * @param primaryStage Primary stage to be closed by the button
 */
public ExitButton(String text, Stage primaryStage){
    this.exitButton = new Button(text); // Create exit button
            exitButton.setOnAction(e -> closeProgram(primaryStage, true)); // Call are-you-sure-window
        primaryStage.setOnCloseRequest(e -> { // X-button logic
            e.consume(); // Consume close request
            closeProgram(primaryStage, true); // Call are-you-sure-window
        });
    this.getChildren().add(exitButton);
}
/**
 * Constructor with input parameter 'enableWarning', which allows you to disable the 'are you sure' warning when closing the application or pressing the exit button.
 * @param text Text to be displayed on the button
 * @param primaryStage Stage to be closed by the button
 * @param enableWarning true if we want to show the are-you-sure warning
 */
public ExitButton(String text, Stage primaryStage, boolean enableWarning){
    this.exitButton = new Button(text); // Create exit button
            exitButton.setOnAction(e -> closeProgram(primaryStage, enableWarning)); // Call are-you-sure-window
        primaryStage.setOnCloseRequest(e -> { // X-button logic
            e.consume(); // Consume close request
            closeProgram(primaryStage, enableWarning); // Call are-you-sure-window
        });
    this.getChildren().add(exitButton); // Put exit button in HBox container
}
/**
 * Logic for closing the program and displaying the are-you-sure-warning.
 * @param stage Stage to be closed
 * @param enableWarning True if the are-you-sure warning is to be enabled
 */
private void closeProgram(Stage stage, boolean enableWarning){
    if (enableWarning) {
        Boolean answer = ConfirmBox.display("Warning", "Are you sure you want to exit?");
        if (answer) stage.close();} // Closes the stage if the user chooses 'yes'
        else stage.close(); // Closes the stage if no prompt was shown.
}

}
