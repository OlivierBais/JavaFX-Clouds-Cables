package com.example.cloudsandcables.GUIObjects;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class RollControls extends VBox {
    private RollButton rollButton = new RollButton();
    private Label outcomeIndicator = new Label("");
    private int outcome = 1;

    public RollControls() {
        this.getChildren().addAll(rollButton, outcomeIndicator);
        this.setAlignment(Pos.CENTER);
        this.setPadding(new Insets(20, 20, 20, 20));
        this.setSpacing(5);
    }

    public RollButton getRollButton() {
        return this.rollButton;
    }

    public int getOutcome() {
        return this.outcome;
    }

    public void setOutcome(int outcome) {
        this.outcome = outcome;
    }

    public void update(int outcome) {
        this.outcome = outcome;
        this.outcomeIndicator.setText(String.valueOf(outcome));
    }

    public int roll() {
        int roll = (int) (Math.random() * 6) + 1;
        return roll;
    }

}
