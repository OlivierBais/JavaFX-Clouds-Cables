package com.example.cloudsandcables;

//TODO: Big tidy-up
// IMPORTS
import javafx.application.Application;
import javafx.collections.*;
import javafx.fxml.FXMLLoader;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.stage.Stage;
import javafx.event.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.example.cloudsandcables.GUIObjects.Board;
import com.example.cloudsandcables.GUIObjects.ExitButton;
import static com.example.cloudsandcables.objects.Constants.*;
import com.example.cloudsandcables.objects.Player;
import com.example.cloudsandcables.objects.PlayerIcon;
import com.example.cloudsandcables.objects.PlayerVBox;
import com.example.cloudsandcables.objects.Players;
import com.example.cloudsandcables.images.*;

import javafx.scene.control.*;
import javafx.scene.control.cell.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

//MAIN
public class Main extends Application {
    // DEBUG MODE: Set this to true to skip the player selection screen and the
    // close window warning
    boolean debugMode = true;
    // SECTION 0: Initialize objects
    // Initialize version names
    static String cacVersion = "1.9";
    static String editionName = "Players-can-move";
    // Initialize booleans for debug mode
    boolean skipPlayerSelect = false;
    boolean enableWarning = true;
    // Initialize window and layouts
    Stage window;
    BorderPane layout;
    VBox playerSelectionLayout = new VBox();
    VBox gameLayout = new VBox();
    // Initialize scenes
    Scene playerSelectionScene = new Scene(playerSelectionLayout, 400, 350); // Set the scene
    Scene gameScene = new Scene(gameLayout, 650, 600); // Set the scene for the game
    // Initialize default number of players (2), and holder of the Players
    // themselves
    int numPlayers = 2;
    Players players = new Players();
    // Initialize miscellaneous objects
    ComboBox<Integer> playerNumberSelector;
    int dist = 3;
    PlayerIcon player1Icon = new PlayerIcon(1);
    PlayerIcon player2Icon = new PlayerIcon(2);
    PlayerIcon player3Icon = new PlayerIcon(3);
    PlayerIcon player4Icon = new PlayerIcon(4);
    // Application launcher
    public static void main(String[] args) {
        launch(args);
    }

    // Application starter, the true 'main' of the application.
    @Override
    public void start(Stage mainStage) throws Exception {
        // Debug Mode logic
        setDebugMode(debugMode);
        // Window settings
        mainStage.setTitle("Clouds & Cables " + cacVersion + ": " + editionName + " Edition"); // Set window title
        // LAYOUT CONSTRUCTION
        // 1. Array of nodes containing player settings screens (name and col)
        PlayerVBox[] playerVBoxes = populatePlayerSelectionLayout(playerSelectionLayout, mainStage);
        // 2. Exit + continue button; Continue button logic
        Button continueButton = addExitContinueButton(mainStage, playerSelectionLayout, enableWarning);
        // 3. Board and board logic, for the game scene. To be tidied up later.
        Board board = new Board(10, numPlayers);
        // 4. COMMENTED code for board image creation
        // Image boardImage = new
        // Image("C:\\Users\\BaisOlivier(Calco)\\JavaProject\\CloudsAndCables\\CloudsAndCables\\src\\main\\java\\com\\example\\cloudsandcables\\images\\boardImgTest.png");
        // ImageView boardImageView = new ImageView(boardImage);
        // The boardPane holds the board and the image atop each other.
        Pane boardPane = new Pane();
        boardPane.getChildren().addAll(board);
        continueButton.setOnAction(e -> {
            // This one lambda function will hold all the game's logic :'(
            // 'handleContinueButton' creates a list of Player objects
            Players savedPlayers = handleContinueButton(mainStage, gameScene, playerVBoxes, board);
            players.setPlayers(savedPlayers, numPlayers);
            board.placeIconsOnBoard(player1Icon, player2Icon, player3Icon, player4Icon, numPlayers);
            // DELETE IF SETICONS WORKS
            // TODO: Remove excess player icons on cont button press.
            // board.getChildren().addAll(player1Icon, player2Icon, player3Icon, player4Icon);
        });
        // GAME SCENE: Holds the game board and controls

        // Header graphic placeholder, to be replaced with nice header logo
        // TODO: change this into a function
        Label headerGraphicPlaceholder = new Label("Clouds & Cables");
        HBox headerGraphic = new HBox(headerGraphicPlaceholder);
        headerGraphic.setAlignment(Pos.CENTER);
        headerGraphic.setSpacing(20);
        // SECTION 2 //
        // Board. The meat of the game!
        board.populateBoard();
        // SECTION 3//
        // Player controls. Needs to be accessible from main.
        HBox controlsHBox = new HBox();
        Button pos3 = new Button("Position +3");

        pos3.setOnAction(f -> {
            board.moveIcon(player1Icon, dist);
            System.out.println("Player 1 moved to: " + players.getPlayer(0).getPosition());
            dist += 3;
            System.out.println("Value of dist: " + dist);
        });
        controlsHBox.getChildren().add(pos3);
        controlsHBox.setAlignment(Pos.CENTER);

        // SECTION 4//
        // Footer with exit button, and later, concede button.
        HBox footerHBox = new HBox();
        // Add elements to main layout and set scene
        gameLayout.getChildren().addAll(headerGraphic, boardPane, controlsHBox, footerHBox);

        // Preparatory code for launching the game itself:

        mainStage.show(); // Show window
        mainStage.setScene(playerSelectionScene);
        ;
    }

    // FUNCTIONS
    /**
     * Creates Player settings VBox.
     * 
     * @param playerNum player number for the player to be created, e.g. player 1,
     *                  player 2
     * @return a VBox with the player settings fields: a label, name text field, and
     *         color selector
     */
    public VBox createPlayerSettings(int playerNum) {
        Label playerNumLabel = new Label("Player " + playerNum);
        VBox playerVBox = new VBox();
        playerVBox.getChildren().addAll(playerNumLabel);
        return playerVBox;
    }

    /**
     * Populates the player number selector HBox, and contains the logic that
     * follows from changing the number of players
     * 
     * @param playerNumberHBox   is the Hbox that will contain the player number
     * @param playerSettingsHBox is the HBox that contains player settings VBoxes,
     *                           where players insert their name and color.
     * @return
     */
    public ComboBox<Integer> populatePlayerNumberHBox(HBox playerNumberHBox, HBox playerSettingsHBox) {
        Label playersLabel = new Label("Players: "); // Label for player number
        ObservableList<Integer> playerNumbers = FXCollections.observableArrayList(1, 2, 3, 4); // List of possible
                                                                                               // player numbers, 1-4
        ComboBox<Integer> playerNumberSelector = new ComboBox<>(playerNumbers); // Create a dropdown box with the player
                                                                                // numbers
        playerNumberSelector.setValue(numPlayers);
        playerNumberHBox.getChildren().addAll(playersLabel, playerNumberSelector); // Add the label and dropdown box
        playerNumberHBox.setAlignment(Pos.CENTER); // Center the HBox
        return playerNumberSelector;
    }

    public PlayerVBox[] populatePlayerSettingsHBox(HBox playerSettingsHBox) {
        // Create a settings selection element (PlayerVBox) for each player, with
        // default parameters:
        PlayerVBox player1VBox = new PlayerVBox(1, "Ed", "Red");
        PlayerVBox player2VBox = new PlayerVBox(2, "Gene", "Green");
        PlayerVBox player3VBox = new PlayerVBox(3, "Lou", "Blue");
        PlayerVBox player4VBox = new PlayerVBox(4, "Jack", "Black");
        // We default to two players. So players 3 and 4 are disabled unless the user
        // changes the selection:
        player3VBox.disable();
        player4VBox.disable();
        // Add the PlayerVBoxes to the playerSettingsHBox
        playerNumberSelector
                .setOnAction(e -> {
                    numPlayers = handleNumPlayerChange(player1VBox, player2VBox, player3VBox, player4VBox);
                });
        playerSettingsHBox.getChildren().addAll(player1VBox, player2VBox, player3VBox, player4VBox);
        PlayerVBox[] playerVBoxes = { player1VBox, player2VBox, player3VBox, player4VBox };
        return playerVBoxes;
    }

    /**
     * Handles all logic for when the player number dropdown box is changed.
     * Inelegant but effective.
     * 
     * @param player1VBox
     * @param player2VBox
     * @param player3VBox
     * @param player4VBox
     */
    public int handleNumPlayerChange(PlayerVBox player1VBox, PlayerVBox player2VBox, PlayerVBox player3VBox,
            PlayerVBox player4VBox) {
        int numPlayers = playerNumberSelector.getValue(); // Store the newly changed number of players.
        // We use a switch case to disable or enable the player settings VBoxes based on
        // the number of players selected.
        switch (numPlayers) {
            case 1:
                player1VBox.enable();
                player2VBox.disable();
                player3VBox.disable();
                player4VBox.disable();
                return numPlayers;
            case 2:
                player1VBox.enable();
                player2VBox.enable();
                player3VBox.disable();
                player4VBox.disable();
                return numPlayers;
            case 3:
                player1VBox.enable();
                player2VBox.enable();
                player3VBox.enable();
                player4VBox.disable();
                return numPlayers;
            case 4:
                player1VBox.enable();
                player2VBox.enable();
                player3VBox.enable();
                player4VBox.enable();
                return numPlayers;
            default:
                player1VBox.enable();
                player2VBox.disable();
                player3VBox.disable();
                player4VBox.disable();
                return numPlayers;
        }
    }

    public PlayerVBox[] populatePlayerSelectionLayout(VBox playerSelectionLayout, Stage stage) {
        Label welcomeLogoPlaceholder = new Label(
                "*PLACEHOLDER* Welcome to Clouds & Cables Version " + cacVersion + "!"); // Welcome image goes here.
        Label howManyPlayers = new Label("How many players are you?");
        HBox playerNumberHBox = new HBox(); // Create empty HBox that will contain player number selector
        HBox playerSettingsHBox = new HBox(); // Create empty HBox for player settings interface
        // Now to populate these layout objects with UI elements
        // Populate playerNumberHBox with UI elements, and store the selected num of
        // players:
        playerNumberSelector = populatePlayerNumberHBox(playerNumberHBox, playerSettingsHBox);
        // Populate player settings HBox with player settings VBoxes; store player
        // settings VBoxes in a non-deep-copied array for access from main:
        PlayerVBox[] playerVBoxes = populatePlayerSettingsHBox(playerSettingsHBox);

        // Test button for debugging. Normally disabled.
        Button testButton = new Button("Test");
        // testButton.setOnAction();
        // Layout configuration
        playerSelectionLayout.getChildren().addAll(welcomeLogoPlaceholder, howManyPlayers, playerNumberHBox,
                playerSettingsHBox);
        playerSelectionLayout.setSpacing(10); // Set spacing between elements
        playerSelectionLayout.setAlignment(Pos.CENTER);
        return playerVBoxes;
    }

    /**
     * Create exit button and continue button
     * 
     * @param mainStage             must be passed on so that the exit button can
     *                              fulfill its purpose
     * @param playerSelectionLayout is the grand layout to which the buttons are
     *                              added
     * @return the continue button is returned so that its on-click event can be
     *         handled from Main.
     */
    public Button addExitContinueButton(Stage mainStage, VBox playerSelectionLayout, boolean enableWarning) {
        // Make exit button, as defined in GUIObjects
        ExitButton exitButton = new ExitButton("Exit", mainStage, enableWarning);
        Button continueButton = new Button("Continue"); // Make continue button. Handled in main.
        HBox exitContinueHBox = new HBox(exitButton, continueButton); // HBox contains buttons
        exitContinueHBox.setAlignment(Pos.CENTER); // layout settings
        exitContinueHBox.setSpacing(10);
        playerSelectionLayout.getChildren().add(exitContinueHBox); // Add HBox with buttons to grand layout
        return continueButton; // Pass continue button to main where it can be handled.
    }

    /**
     * Creates an arrayList containing our max. 4 Player objects. Called upon by the
     * 'continue' button.
     * 
     * @param playerVBoxes Vboxes wherein the user filled in player details
     * @return arrayList containing max. 4 Player objects
     */
    public Players createPlayers(PlayerVBox[] playerVBoxes) {
        ArrayList<Player> playersList = new ArrayList<>();
        for (int i = 0; i < numPlayers; i++) { // Loop over the selected number of players
            int playerNumber = playerVBoxes[i].getPlayerNum(); // Get inserted info from Player VBoxes
            String playerName = playerVBoxes[i].getPlayerName();
            String playerColor = playerVBoxes[i].getPlayerColor();
            // Construct player based on gotten info, and add to the arrayList.
            Player tempPlayer = new Player(playerNumber, playerName, playerColor, 1);
            playersList.add(tempPlayer);
        }
        numPlayers = playersList.size();
        Players tempPlayers = new Players(playersList, numPlayers);
        return tempPlayers;
    }

    public void setDebugMode(boolean debugMode) {
        if (debugMode) {
            skipPlayerSelect = true;
            enableWarning = false;
        }
    }

    public Players handleContinueButton(Stage mainStage, Scene gameScene, PlayerVBox[] playerVBoxes, Board board) {
        mainStage.setScene(gameScene);
        Players tempPlayers = createPlayers(playerVBoxes);
        for (int i = 0; i < numPlayers; i++) {
            System.out.println(
                    "Player " + tempPlayers.getPlayer(i).getPlayerNum() + " is called "
                            + tempPlayers.getPlayer(i).getName()
                            + ", and they chose " + tempPlayers.getPlayer(i).getColor() + ".");
        }
        return tempPlayers;
    }

}
