package com.example.cloudsandcables.GUIObjects;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class GameTerminal extends VBox {

    public GameTerminal() {
        this.setAlignment(Pos.CENTER_RIGHT);
    }

    public void print(String text) {
        this.getChildren().add(new Label(text));
        if (this.getChildren().size() > 4)
            this.getChildren().removeFirst();
    }



}
